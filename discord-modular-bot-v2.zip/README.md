# Discord Socket Listener - Modular Version

Versi modular dari Discord Bot yang memonitor channel dan broadcast pesan melalui socket server.

## Struktur Project

\`\`\`
├── app.py                 # Main application orchestrator
├── config.py             # Configuration management
├── requirements.txt      # Python dependencies
├── run_client.py        # Client runner script
├── client/
│   └── socket_client.py # Socket client implementation
├── models/
│   └── message.py       # Data models
├── services/
│   ├── channel_manager.py    # Channel monitoring management
│   ├── discord_bot.py        # Discord bot service
│   ├── message_processor.py  # Message processing service
│   └── socket_server.py      # Socket server service
└── utils/
    └── logger.py        # Logging utilities
\`\`\`

## Setup

1. Install dependencies:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

2. Set environment variables:
\`\`\`bash
export DISCORD_BOT_TOKEN="your_bot_token_here"
export SOCKET_HOST="localhost"  # optional, default: localhost
export SOCKET_PORT="8888"       # optional, default: 8888
\`\`\`

## Docker Setup

### Prerequisites
- Docker
- Docker Compose

### Quick Start

1. Clone repository dan masuk ke directory:
\`\`\`bash
git clone <repository-url>
cd discord-socket-listener
\`\`\`

2. Copy dan edit environment file:
\`\`\`bash
cp .env.example .env
# Edit .env file dengan Discord bot token Anda
\`\`\`

3. Build dan start services:
\`\`\`bash
# Using Makefile (recommended)
make build
make up

# Or using docker-compose directly
docker-compose build
docker-compose up -d discord-bot redis
\`\`\`

4. Check logs:
\`\`\`bash
make logs
# Or
docker-compose logs -f discord-bot
\`\`\`

### Available Commands

\`\`\`bash
# Build images
make build

# Start basic services (bot + redis)
make up

# Start in development mode with hot reload
make up-dev

# Start in production mode with resource limits
make up-prod

# Start all services including database and monitoring
make up-full

# Start socket client for testing
make client

# View logs
make logs

# Open shell in bot container
make shell

# Stop services
make down

# Clean up everything
make clean

# Check status
make status
\`\`\`

### Service Profiles

The docker-compose setup includes several service profiles:

- **Default**: Discord bot + Redis
- **client**: Socket client for testing
- **database**: PostgreSQL database
- **monitoring**: Prometheus + Grafana

Start specific profiles:
\`\`\`bash
# Start with database
docker-compose --profile database up -d

# Start with monitoring
docker-compose --profile monitoring up -d

# Start everything
docker-compose --profile database --profile monitoring --profile client up -d
\`\`\`

### Environment Variables

All configuration is done via environment variables in `.env` file:

\`\`\`env
DISCORD_BOT_TOKEN=your_bot_token_here
SOCKET_HOST=0.0.0.0
SOCKET_PORT=8888
LOG_LEVEL=INFO
\`\`\`

### Volumes and Persistence

- `./logs` - Application logs
- `./data` - Application data
- `redis_data` - Redis data
- `postgres_data` - PostgreSQL data (if using database profile)

### Health Checks

All services include health checks:
- Discord bot: Socket server connectivity
- Redis: Redis ping
- PostgreSQL: Database connectivity

### Monitoring (Optional)

When using monitoring profile:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/admin)

## Usage

### Menjalankan Bot

\`\`\`bash
python app.py
\`\`\`

### Menjalankan Client Listener

\`\`\`bash
python run_client.py [host] [port]
\`\`\`

Contoh:
\`\`\`bash
python run_client.py localhost 8888
\`\`\`

## Bot Commands

- `!listen [channel_id]` - Mulai monitor channel (default: channel saat ini)
- `!unlisten [channel_id]` - Stop monitor channel (default: channel saat ini)  
- `!status` - Tampilkan status monitoring

## Features

### Modular Architecture
- **Config Management**: Centralized configuration dengan environment variables
- **Channel Manager**: Service untuk manage monitored channels dengan persistence
- **Message Processor**: Service untuk process dan distribute pesan
- **Socket Server**: Service untuk broadcast ke clients
- **Discord Bot**: Service untuk handle Discord events dan commands
- **Logger Utility**: Centralized logging management

### Improvements dari Versi Monolith
- ✅ Separation of concerns
- ✅ Dependency injection
- ✅ Configuration management
- ✅ Error handling improvements
- ✅ Graceful shutdown
- ✅ Persistent channel monitoring
- ✅ Concurrent message broadcasting
- ✅ Better logging system

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DISCORD_BOT_TOKEN` | Discord bot token | Required |
| `BOT_PREFIX` | Bot command prefix | `!` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `LOG_FILE` | Bot log file | `discord_bot.log` |
| `MESSAGE_LOG_FILE` | Message log file | `discord_messages.txt` |
| `SOCKET_HOST` | Socket server host | `localhost` |
| `SOCKET_PORT` | Socket server port | `8888` |
| `MAX_CONNECTIONS` | Max socket connections | `5` |
| `HEARTBEAT_INTERVAL` | Heartbeat interval (seconds) | `30` |

## Architecture Benefits

1. **Maintainability**: Setiap modul memiliki tanggung jawab yang jelas
2. **Testability**: Mudah untuk unit testing karena dependencies diinjected
3. **Scalability**: Mudah untuk menambah broadcaster atau processor baru
4. **Configuration**: Centralized config dengan environment variables
5. **Error Handling**: Better error isolation dan recovery
6. **Monitoring**: Comprehensive logging across all modules
