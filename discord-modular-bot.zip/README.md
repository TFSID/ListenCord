# Discord Socket Listener - Modular Version

Versi modular dari Discord Bot yang memonitor channel dan broadcast pesan melalui socket server.

## Struktur Project

\`\`\`
├── app.py                 # Main application orchestrator
├── config.py             # Configuration management
├── requirements.txt      # Python dependencies
├── run_client.py        # Client runner script
├── client/
│   └── socket_client.py # Socket client implementation
├── models/
│   └── message.py       # Data models
├── services/
│   ├── channel_manager.py    # Channel monitoring management
│   ├── discord_bot.py        # Discord bot service
│   ├── message_processor.py  # Message processing service
│   └── socket_server.py      # Socket server service
└── utils/
    └── logger.py        # Logging utilities
\`\`\`

## Setup

1. Install dependencies:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

2. Set environment variables:
\`\`\`bash
export DISCORD_BOT_TOKEN="your_bot_token_here"
export SOCKET_HOST="localhost"  # optional, default: localhost
export SOCKET_PORT="8888"       # optional, default: 8888
\`\`\`

## Usage

### Menjalankan Bot

\`\`\`bash
python app.py
\`\`\`

### Menjalankan Client Listener

\`\`\`bash
python run_client.py [host] [port]
\`\`\`

Contoh:
\`\`\`bash
python run_client.py localhost 8888
\`\`\`

## Bot Commands

- `!listen [channel_id]` - Mulai monitor channel (default: channel saat ini)
- `!unlisten [channel_id]` - Stop monitor channel (default: channel saat ini)  
- `!status` - Tampilkan status monitoring

## Features

### Modular Architecture
- **Config Management**: Centralized configuration dengan environment variables
- **Channel Manager**: Service untuk manage monitored channels dengan persistence
- **Message Processor**: Service untuk process dan distribute pesan
- **Socket Server**: Service untuk broadcast ke clients
- **Discord Bot**: Service untuk handle Discord events dan commands
- **Logger Utility**: Centralized logging management

### Improvements dari Versi Monolith
- ✅ Separation of concerns
- ✅ Dependency injection
- ✅ Configuration management
- ✅ Error handling improvements
- ✅ Graceful shutdown
- ✅ Persistent channel monitoring
- ✅ Concurrent message broadcasting
- ✅ Better logging system

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DISCORD_BOT_TOKEN` | Discord bot token | Required |
| `BOT_PREFIX` | Bot command prefix | `!` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `LOG_FILE` | Bot log file | `discord_bot.log` |
| `MESSAGE_LOG_FILE` | Message log file | `discord_messages.txt` |
| `SOCKET_HOST` | Socket server host | `localhost` |
| `SOCKET_PORT` | Socket server port | `8888` |
| `MAX_CONNECTIONS` | Max socket connections | `5` |
| `HEARTBEAT_INTERVAL` | Heartbeat interval (seconds) | `30` |

## Architecture Benefits

1. **Maintainability**: Setiap modul memiliki tanggung jawab yang jelas
2. **Testability**: Mudah untuk unit testing karena dependencies diinjected
3. **Scalability**: Mudah untuk menambah broadcaster atau processor baru
4. **Configuration**: Centralized config dengan environment variables
5. **Error Handling**: Better error isolation dan recovery
6. **Monitoring**: Comprehensive logging across all modules
